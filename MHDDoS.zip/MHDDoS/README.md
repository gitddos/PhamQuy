git clone https://github.com/gitddos/ddosbyquy.git
cd ddosbyquy
python2 ddosbyquy.py